Locales['en'] = {
  ['male'] = 'Muž',
  ['female'] = 'Žena',
  ['carjack'] = 'Krádež vozidla: %s, byla zachycena %s na: %s',
  ['combat'] = 'Pouliční bitka: %s, byla zahlédnuta na CCTV na : %s',
  ['gunshot'] = 'Střelba~s~: %s, byla zachycena na : %s',
}